/*
SQL> desc admin
 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------
 ADMIN_ID                                  NOT NULL VARCHAR2(20)
 ADMIN_NAME                                NOT NULL VARCHAR2(60)
 ADMIN_TYPE                                         VARCHAR2(10)
 ADMIN_FNAME                               NOT NULL VARCHAR2(60)
 ADMIN_LNAME                               NOT NULL VARCHAR2(60)
 DISPLAY_IMAGE                                      VARCHAR2(30)
 DESCRIPTION                                        VARCHAR2(50)
 CREATED                                            DATE
 CREATED_BY                                         VARCHAR2(10)
 THEME                                              VARCHAR2(30)

*/


insert into admin values (
'001',
'xfreyje',
'org',
'Jeff',
'Frey',
'/img/token.jpg',
'best guy ever',
sysdate,
'admin',
'blue')
/
