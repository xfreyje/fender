/*
SQL> desc organization
 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------
 ORG_ID                                    NOT NULL VARCHAR2(20)
 ORG_NAME                                  NOT NULL VARCHAR2(60)
 ORG_TYPE                                  NOT NULL VARCHAR2(20)
 ORG_DESC                                  NOT NULL VARCHAR2(500)
 DISPLAY_IMAGE                                      VARCHAR2(30)
 CREATED                                            DATE
 CREATED_BY                                         VARCHAR2(10)
 EMAIL                                              VARCHAR2(50)
 STREET                                             VARCHAR2(80)
 CITY                                               VARCHAR2(30)
 STATE                                              VARCHAR2(2)
 ZIPCODE                                            VARCHAR2(10)
 COUNTRY                                            VARCHAR2(20)
 HOME_PHOME                                         VARCHAR2(20)
 MOBILE_PHOME                                       VARCHAR2(20)
 WORK_PHOME                                         VARCHAR2(20)
 THEME                                              VARCHAR2(30)
 ADMIN_ID                                  NOT NULL VARCHAR2(20)

*/

insert into organization values (
'001',
'Belle River Minor Baseball',
'baseball',
'BRMBA is a local minor league baseball org in BR, Ontario',
'/img/token.jpg',
sysdate,
'admin',
'xfreyje@gmail.com',
'101 Main',
'Belle River',
'ON',
'N8N5C3',
'Canada',
'519-567-0587',
'519-567-0587',
'519-567-0587',
'blue',
'001')
/
