ALTER TABLE organization ADD CONSTRAINT fk_org_admin 
FOREIGN KEY (admin_id) REFERENCES admin (admin_id);

ALTER TABLE account ADD CONSTRAINT fk_org_id 
FOREIGN KEY (org_id) REFERENCES organization (org_id);

ALTER TABLE player ADD CONSTRAINT fk_person_id 
FOREIGN KEY (person_id) REFERENCES person (person_id);
