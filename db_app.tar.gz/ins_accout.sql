insert into account values (
'001',
'001',
'xfreyje',
'org',
'001',
'Jeff',
'Frey',
'/img/token.jpg',
'best guy ever',
'admin',
sysdate,
'brmba',
'xfreyje@gmail.com')
/
